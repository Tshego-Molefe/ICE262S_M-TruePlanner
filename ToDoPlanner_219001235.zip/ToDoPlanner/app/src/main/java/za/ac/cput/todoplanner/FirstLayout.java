package za.ac.cput.todoplanner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstLayout extends AppCompatActivity {
    DatabaseHelper DatabaseHelp;
    EditText editID, editTask, editStatus;
    Button AddButton, ViewButton, DeleteButton, UpdateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelp = new DatabaseHelper(this);
        editTask = findViewById(R.id.editText_Task);
        AddButton = findViewById(R.id.button_add);
        ViewButton = findViewById(R.id.button_view);
        DeleteButton = findViewById(R.id.button_delete);
        UpdateButton = findViewById(R.id.button_update);


        AddData();
        UpdateData();
        ViewTasks();
        DeleteData();

    }




    public void AddData() {

        AddButton.setOnClickListener(
                (v) -> {
                    boolean IsInserted = DatabaseHelp.insertData(editTask.getText().toString(), editStatus.getText().toString());

                    if (IsInserted) {
                        Toast.makeText(FirstLayout.this, "Data is inserted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(FirstLayout.this, "Data not inserted", Toast.LENGTH_SHORT).show();
                    }

                }
        );
    }



    public void ViewTasks() {

        ViewButton.setOnClickListener(
                (v) -> {
                    Cursor res = DatabaseHelp.viewAllTasks();
                    if (res.getCount() == 0) {
                        showMessage("Error", "Nothing found");
                        return;
                    }

                    StringBuffer buffer = new StringBuffer();
                    while (res.moveToNext()) {
                        buffer.append("ID" + res.getString(0) + "\n");
                        buffer.append("TASK" + res.getString(1) + "\n");
                        buffer.append("STATUS" + res.getString(2) + "\n");
                    }
                    showMessage("Data", buffer.toString());
                }
        );
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void DeleteData(){
        DeleteButton.setOnClickListener(
                (v) -> {
                    Integer deletedRows = DatabaseHelp.deleteData(editID.getText().toString());
                    if (deletedRows > 0) {
                        Toast.makeText(FirstLayout.this, "Data deleted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(FirstLayout.this, "Data not deleted", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
    public void UpdateData(){
        UpdateButton.setOnClickListener(
                (v) -> {
                    boolean IsUpdated = DatabaseHelp.updateTasks(editID.getText().toString(),editTask.getText().toString(),
                            editStatus.getText().toString());
                    if(IsUpdated){
                        Toast.makeText(FirstLayout.this, "Tasks updated",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(FirstLayout.this, "Tasks not updated",Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

}