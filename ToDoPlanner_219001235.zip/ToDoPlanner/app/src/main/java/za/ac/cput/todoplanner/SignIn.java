package za.ac.cput.todoplanner;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignIn extends AppCompatActivity {
    TextView appName;
    EditText userName, passWord;
    Button btnSignIn;
    DBHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        appName = findViewById(R.id.app_name);
        userName = findViewById(R.id.signUsername);
        passWord = findViewById(R.id.signPassword);
        btnSignIn = findViewById(R.id.btnIn);

        myDb = new DBHelper(this);

        btnSignIn.setOnClickListener(v -> {
            String user = userName.getText().toString();
            String pass = passWord.getText().toString();

            if(user.equals("") || pass.equals("")) {
                Toast.makeText(SignIn.this, "Fill in all fields to Sign In ", Toast.LENGTH_SHORT).show();
            }
            else{
                Boolean result = myDb.checkUsernamePassword(user, pass);
                if (result){
                    Intent intent = new Intent(getApplicationContext(), Main.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(SignIn.this, "Incorrect username or password ", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}