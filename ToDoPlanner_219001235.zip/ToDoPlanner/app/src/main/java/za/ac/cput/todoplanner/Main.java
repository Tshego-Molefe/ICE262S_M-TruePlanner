package za.ac.cput.todoplanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Main extends AppCompatActivity {

    FloatingActionButton AddButton;
    DatabaseHelper myHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        AddButton = findViewById(R.id.AddButton);

        myHelper = new DatabaseHelper(Main.this);
        AddButton.setOnClickListener(
                v -> {
                    Intent intent = new Intent(Main.this, MainActivity.class);
                    startActivity(intent);
                }
        );
    }
}
