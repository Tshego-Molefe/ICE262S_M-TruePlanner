package za.ac.cput.todoplanner;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    TextView appName;
    EditText userName, password, repassword;
    Button signInButton, registerButton;
    DBHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        appName = findViewById(R.id.app_name);
        userName = findViewById(R.id.username);
        password = findViewById(R.id.password);
        repassword = findViewById(R.id.repassword);
        signInButton = findViewById(R.id.signinButton);
        registerButton = findViewById(R.id.registerButton);

        myDb = new DBHelper(this);

        registerButton.setOnClickListener(v -> {
            String user = userName.getText().toString();
            String pword = password.getText().toString();
            String repword = repassword.getText().toString();

            if(user.equals("") || pword.equals("") || repword.equals("")){
                Toast.makeText(Register.this, "Fill in all fields ", Toast.LENGTH_SHORT).show();
            }
            else{
                if(pword.equals(repword))
                {
                    Boolean userIsValid = myDb.checkUsername(user);
                    if (userIsValid == false)
                    {
                        Boolean regResult = myDb.insertData(user,pword);

                        if(regResult== true){
                            Toast.makeText (Register.this, "Registration successful. ", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),SignIn.class);
                            startActivity(intent);
                        }

                        else{
                            Toast.makeText(Register.this, "Registration unsuccessful, try again later. ", Toast.LENGTH_LONG).show();
                        }
                    }
                    else{
                        Toast.makeText(Register.this, "User Already Exists.\n Please Sign In ", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(Register.this, "Passwords do not match. ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SignIn.class);
                startActivity(intent);
            }
        });


    }
}